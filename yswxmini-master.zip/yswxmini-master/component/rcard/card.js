// component/card/card.js
Component({
  /**
   * 组件的属性列表
   */
  options: {
    styleIsolation: "apply-shared"
  },
  properties: {
    // 是否选择显隐开关
    switch: {
      type: Boolean,
    },
    // 卡片标题
    name: {
      type: String,
      value: "表单标题name"
    },
    // 卡片开关状态
    // true为打开状态 false为关闭状态
    tab: {
      type: Boolean,
    },
    // 卡片内容
    content: {
      type: String,
      value: ""
    },
    // 用于确定父页面传值位置
    num: {
      type: String,
      value: 0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    switch: true,
    name: "",
    tab: false,
    head: "",
    num: ""
  },

  lifetimes:{
    attached: function(){
      // console.log(this.properties);
      this.setData({
        switch:  this.properties.switch,
        name: this.properties.name,
        tab: this.properties.tab ,
        content: this.properties.content,
        num: this.properties.num
      })
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 控制卡片开关
    _tableBtn: function () {
      var tab = !this.data.tab;
      this.setData({
        tab: tab
      })
    },
  }
})