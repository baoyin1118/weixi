const {
  CalculateByServiceClass
} = require("../../utils/count");
const {
  formatTable
} = require("../../utils/format");
const {
  accMul
} = require("../../utils/util");

// component/card/card.js
Component({
  /**
   * 组件的属性列表
   */
  options: {
    styleIsolation: "apply-shared"
  },
  properties: {
    biptype: {
      type: String,
      value: '是' // 默认值
    },
    // 卡片类型
    type: {
      type: String,
      value: ""
    },
    // 是否显示多选框
    choose: {
      type: Boolean,
    },
    // 是否显示加减器
    addsub: {
      type: Boolean,
    },
    // 是否选择显隐开关
    switch: {
      type: Boolean,
    },
    // 卡片标题
    name: {
      type: String,
      value: "表单标题name"
    },
    // 卡片开关状态
    // true为打开状态 false为关闭状态
    tab: {
      type: Boolean,
    },
    // 卡片标题
    head: {
      type: Array,
      value : ["模块", "远程","现场","选购"]
    },
    // 卡片列表
    list: {
      type: Array,
      value: [{
        name: "总账",
        price: 3500,
        checked: false,
      }, {
        name: "总账",
        price: 3500,
        checked: true,
      }, ]
    },
    // 用户数
    user: {
      type: Number,
      value: 0
    },
    // 用户单价
    userprice: {
      type: Number,
      value: 0
    },
    // 用户总价
    usercount: {
      type: Number,
      value: 0
    },
    // 模块总价
    price: {
      type: Number,
      value: 0
    },
    // 最小用户数
    usermin: {
      type: Number,
      value: 0
    },
    // 用于确定父页面传值位置
    num: {
      type: String,
      value: 0
    },
    //用于显示几个动态数量
    saleparam:{
      type: Number,
      value: 0
    },
    //初始化标记
    initflag:{
      type: Boolean,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    type: "",
    name: "",
    head: [],
    list: [],
    user: 1,
    userprice: 0,
    usercount: 0,
    price: 0,
    usermin: 1,
    num: "",
    count: 0,
    v:"",
    checked:false,
    biptype:''
  },

  lifetimes: {
    attached: function () {
      var that = this;
      this.setData({
        type: this.properties.type || 'choose',
        choose: this.properties.choose,
        addsub: this.properties.addsub,
        switch: this.properties.switch,
        name: this.properties.name,
        tab: this.properties.tab || false,
        head: this.properties.head,
        list: this.properties.list,
        user: this.properties.user || 0,
        userprice: this.properties.userprice || 0,
        usercount: (this.properties.user - this.properties.usermin) * this.properties.userprice || 0,
        price: this.properties.price || 0,
        num: this.properties.num,
        saleparam :this.properties.saleparam,
      }, () => {
        if (that.properties.addsub)
          that._countUserUnitPrice(that.data.list);
      });
      
    }
  },
  // pageLifetimes: {
  //   show: function () {
  //     var that = this;
  //     if (that.properties.addsub)
  //       that._countUserUnitPrice(that.data.list);
  //   }
  // },

  /**
   * 组件的方法列表
   */
  methods: {
    // 控制卡片开关
    _tableBtn: function () {
      var tab = !this.data.tab;
      this.setData({
        tab: tab
      })
    },
    // checked选中改变data
    _changeChecked: function (e) {
      // 改变checked属性
      var that = this;
      var id = parseInt(e.currentTarget.id.split("_")[1]);
      var _list = this.properties.list;
      var status = _list[id].checked;
      status = status ? false : true;
      _list[id].checked = status;
      let v = ""
      if(e.currentTarget.dataset['v']){
        v = e.currentTarget.dataset['v'];
      }
      let checked = false;
      if(e.currentTarget.dataset['checked']){
        checked = e.currentTarget.dataset['checked'];
      }
      // 赋值
      that.setData({
        list: _list,
        initflag:false,
        v:v,
        checked:checked
      }, () => {
       

        // 计算用户单价
        that._countUserUnitPrice(_list);

      });
    },
    // 绑定addsub组件传值
    _handleAddsub: function (res) {
      var {
        user
      } = this.data;
      var _user = res.detail.user || user;
      this.setData({
        user: _user
      }, () => {
        this._countUserPrice();
      });
    },
    //计算模块用户单价
    _countUserUnitPrice(list) {
      // console.log("模块列表", list);
      // 独立用户单价, 模块用户单价
      var alonePrice = 0,
        modelPrice = 0;
      // 遍历
      list.map((l) => {
        if (l.checked) {
          // 用户设置独立计算 且 按用户计算
          if ((l.is_alone === 'true') && (l.serviceIsByUser === 'true')) {
            alonePrice += l.serviceUnitPrice;
          }
          // 用户按模块计算 且 按用户计算
          if (l.is_alone !== 'true' && this.properties.addsub && modelPrice == 0) {
            modelPrice = l.unit_price;
          }
        }
      });
      this.setData({
        userprice: (alonePrice + modelPrice)
      }, () => this._countUserPrice())
    },
    // 计算用户总价
    _countUserPrice() {
      var count = this.data.usercount;
      var user = this.data.user - this.data.usermin;
      count = accMul(user, this.data.userprice);
      this.setData({
        usercount: count
      }, () => {
        this.sendValue()
      })
    },
    // 传值给父
    sendValue: function () {
      var res = this.data;
      this.triggerEvent("bindCard", res);
    },
  }
})