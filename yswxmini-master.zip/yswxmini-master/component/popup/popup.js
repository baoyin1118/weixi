// component/popup/popup.js
Component({
  options:{
    multipleSlots:true,
    styleIsolation: "apply-shared"
  },
  
  /**
   * 组件的属性列表
   */
  properties: {
    name:{
      type: String,
      value: ""
    },
    type:{
      type: String,
      value: ""
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    name: "",
    show: false,
    note: false // 是否显示提示语
  },
  lifetimes:{
    attached:function(){
      this.setData({
        name: this.properties.name,
        show: true
      })
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    _inputName:function(e){
      if(this.data.note){
        this.setData({
          note: false
        })
      }
      this.setData({
        name: e.detail.value
      });
    },
    _cancel: function(){
      this.setData({
        show: false
      }),
      this.sendValue();
    },
    _save: function(){
      if(!this.data.name){
        this.setData({
          note: true
        })
      }
      this.sendValue();
    },
    sendValue: function(){
      var res = this.data;
      this.triggerEvent("bindPopup", res);
    }
  }
})
