// component/addsub/addsub.js
Component({
  /**
   * 组件的属性列表
   */
  options: {
    styleIsolation: "apply-shared"
  },
  properties: {
    // 加减器标题
    title: {
      type: String,
      value: '购买年限'
    },
    // 加减器值
    num: {
      type: Number,
      value: 1
    },
    // 加减器最低值
    nummin: {
      type: Number,
      value: 1
    },
    // 对应的父组件的属性名
    type: {
      type: String,
      value: ""
    },
    // 提示弹框
    toast: {
      type: String,
      value: "输入不合法"
    },
    // 提示文本
    note: {
      type: String,
      value: ""
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    title: "标题title",
    num: 0,
    nummin: 0,
    type: "",
    note: "",
    notestatus: false,
  },

  lifetimes: {
    attached: function () {
      if (this.properties.nummin == 0) {
        this.setData({
          nummin: 1
        })
      }
      if (this.properties.num == 0) {
        this.setData({
          num: 1
        })
      }
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    showNote: function () {
      var status = this.data.notestatus ? false : true;
      this.setData({
        notestatus: status
      })
    },
    inputValue: function (e) {
      var that = this;
      var nummin = this.data.nummin == 0 ? 1 : this.data.nummin;
      var num = e.detail.value ? e.detail.value : 0;
      if (num >= nummin) {
        that.setData({
          num: num
        }, () => {
          that.sendValue(that.data.num);
        });
      } else {
        wx.showToast({
          title: this.data.toast,
          icon: "none"
        });
        that.setData({
          num: nummin
        }, () => {
          that.sendValue(that.data.num);
        });
      }
    },
    btnadd: function () {
      var num = ++this.data.num;
      this.setData({
        num: num
      });
      this.sendValue(num);
    },
    btnsub: function () {
      var that = this;
      var num = this.data.num;
      var nummin = this.data.nummin == 0 ? 1 : this.data.nummin;
      if (num > nummin + 1) {
        that.setData({
          num: --num
        }, () => {
          that.sendValue(that.data.num);
        });
      } else {
        wx.showToast({
          title: this.data.toast,
          icon: "none"
        });
        that.setData({
          num: nummin,
        }, () => {
          that.sendValue(that.data.num);
        });
      }
    },
    // 传值给父
    sendValue: function (num) {
      var res = {};
      var type = this.data.type;
      res[type] = num;
      this.triggerEvent("bindAddsub", res);
    }
  }
})