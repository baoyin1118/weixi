// 用户信息

var openId = "";
var phone = "";
var userInfo = {};

module.exports = {
  OPENID: openId,
  PHONE: phone,
  USERINFO: userInfo
}