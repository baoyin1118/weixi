// 基础信息

// 页面路径
// name 页面名称
// path 页面路径
// login 是否判断登录
// enable 是否判断权限

// 主页
const page_index = {
  name: 'index',
  path: "/pages/index/index"
}; 

// 我的
const page_my = {
  name: "my",
  path: "/pages/my/my"
}; 
// 登录
const page_login = {
  name: "login",
  path: "/pages/login/login"
}; 


// 用户信息
const page_userinfo = {
  name: "userinfo",
  path: "/pages/userinfo/userinfo"
}


//报价说明
const profession = {
  name: "profession",
  path: "/pages/profession/profession"
}
//专业版
const profession_package = {
  name: "professionpackage",
  path: "/pages/professionpackage/professionpackage"
}
//单条报价记录
const record = {
  name: "record",
  path: "/pages/record/record"
}

//多条报价记录
const records = {
  name: "records",
  path: "/pages/records/records"
}

//交付包报价
const pack = {
  name: "pack",
  path: "/pages/pack/pack"
}
//BIP模式
const professionBipMode = {
  name: "professionBipMode",
  path: "/pages/professionBipMode/professionBipMode"
}
module.exports = {
  PAGE_INDEX: page_index, // 主页
  PAGE_LOGIN: page_login, // 激活登录
  PAGE_MY: page_my, // 我的
  PAGE_USERINFO: page_userinfo, // 用户信息
  PAGE_PROFESSION: profession,//报价说明
  PAGE_PROFESSION_PACKAGE:profession_package,//专业版
  PAGE_RECORD:record,//单条报价记录
  PAGE_RECORDS:records,//多条报价记录,
  PAGE_PACK:pack,//交付包报价
  PAGE_PROFESSIONBIPMODE:professionBipMode,//BIP模式
}