// 表格模板

// index
const template_home = [{
  name: "计算说明",
  page: "profession"
}, {
  name: "专业版",
  page: "profession_package"
},{
  name: "专业版交付包",
  page: "pack"
}];


const template_home_sale = [ 
//   {
//   name: "自选下单",
//   page: "sale"
// },
{
  name: "自助下单",
  page: "page0",
  removekey:"checkedObj"
}];

// rules
const template_rules = [{
  head: "",
  text: ""
}]

// trade
const template_trade = [{
  head: ["模块", "价格", "选购"],
  name: "财务管理",
  user: 1,
  list: [{
    name: "总账",
    price: 3500
  }, {
    name: "财务报表",
    price: 1500
  }, {
    name: "现金管理",
    price: 1500
  }, {
    name: "应收管理",
    price: 1500
  }, {
    name: "应付管理",
    price: 1500
  }]
}, {
  name: "供应链服务",
  user: 1,
  list: [{
    name: "采购管理",
    price: 5000
  }, {
    name: "库存管理",
    price: 5000
  }, {
    name: "销售管理",
    price: 5000
  }]
}];

// trade-test
const template_trade_test = [{
  name: "财务管理",
  user: 5,
  head: ["模块", "价格", "选购"],
  list: [{
    name: "总账",
    price: 3500,
    checked: true,
  }, {
    name: "财务报表",
    price: 1500
  }, {
    name: "现金管理",
    price: 1500
  }, {
    name: "应收管理",
    price: 1500
  }, {
    name: "应付管理",
    price: 1500
  }]
}, {
  name: "供应链服务",
  user: 1,
  list: [{
    name: "采购管理",
    price: 5000
  }, {
    name: "库存管理",
    price: 5000
  }, {
    name: "销售管理",
    price: 5000
  }]
}];

// history
const template_history = [{
  name: '测试历史记录',
  time: '2020-09-23 22:00:00',
  price: '580.00',
  type: 'newTrade'
}, {
  name: '测试历史记录',
  time: '2020-09-23 22:00:00',
  price: '580.00',
  type: 'addTrade'
}]

module.exports = {
  TEMPLATE_HOME: template_home,
  TEMPLATE_HOME_SALE: template_home_sale,
  TEMPLATE_RULES: template_rules,
  TEMPLATE_TRADE: template_trade,
  TEMPLATE_TRADE_TEST: template_trade_test,
  TEMPLATE_HISTORY: template_history
}