var countryCodeData = [{
  "data": [{
    "countryName": "中国",
    "countryPinyin": "zhong guo",
    "phoneCode": "86",
    "countryCode": "CN",
    "reg": "/^(\\+?0?86\\-?)?1[345789]\\d{9}$/"
  }, {
    "countryName": "中国香港",
    "countryPinyin": "zhong guo xiang gang te bie xing zheng qu",
    "phoneCode": "852",
    "countryCode": "HK",
    "reg": "/^(\\+?852\\-?)?[569]\\d{3}\\-?\\d{4}$/"
  }, {
    "countryName": "中国澳门",
    "countryPinyin": "zhong guo ao men te bie xing zheng qu",
    "phoneCode": "853",
    "countryCode": "MO",
    "reg": "/^(\\+?853\\-?)?[6]([8|6])\\d{5}$/"
  }, {
    "countryName": "中国台湾",
    "countryPinyin": "tai wan",
    "phoneCode": "886",
    "countryCode": "TW",
    "reg": "/^(\\+?886\\-?|0)?9\\d{8}$/"
  }, {
    "countryName": "美国",
    "countryPinyin": "mei guo",
    "phoneCode": "1",
    "countryCode": "US",
    "enName": "United States of America",
    "enFullName": "the United States of America",
    "reg": "/^(\\+?1)?[2-9]\\d{2}[2-9](?!11)\\d{6}$/"
  }, {
    "countryName": "马来西亚",
    "countryPinyin": "ma lai xi ya",
    "phoneCode": "60",
    "countryCode": "MY",
    "enName": "Malaysia",
    "reg": "/^(\\+?6?01){1}(([145]{1}(\\-|\\s)?\\d{7,8})|([236789]{1}(\\s|\\-)?\\d{7}))$/"
  }, {
    "countryName": "日本",
    "countryPinyin": "ri ben",
    "phoneCode": "81",
    "countryCode": "JP",
    "enName": "Japan",
    "reg": "/^(\\+?81|0)\\d{1,4}[ \\-]?\\d{1,4}[ \\-]?\\d{4}$/"
  }, {
    "countryName": "英国",
    "countryPinyin": "ying guo",
    "phoneCode": "44",
    "countryCode": "GB",
    "enName": "United Kingdom",
    "enFullName": "the United Kingdom of Great Britain and Northern Ireland",
    "reg": "/^(\\+?44|0)7\\d{9}$/"
  }],
  "key": "hot"
}, {
  "data": [{
    "countryName": "澳大利亚",
    "countryPinyin": "ao da li ya",
    "phoneCode": "61",
    "countryCode": "AU",
    "enName": "Australia",
    "reg": "/^(\\+?61|0)4\\d{8}$/"
  }],
  "key": "A"
}, {
  "data": [{
    "countryName": "比利时",
    "countryPinyin": "bi li shi",
    "phoneCode": "32",
    "countryCode": "BE",
    "enName": "Belgium",
    "enFullName": "the Kingdom of Belgium",
    "reg": "/^(\\+?32|0)4?\\d{8}$/"
  }, {
    "countryName": "巴西",
    "countryPinyin": "ba xi",
    "phoneCode": "55",
    "countryCode": "BR",
    "enName": "Brazil",
    "enFullName": "the Federative Republic of Brazil",
    "reg": "/^(\\+?55|0)\\-?[1-9]{2}\\-?[2-9]{1}\\d{3,4}\\-?\\d{4}$/"
  }, {
    "countryName": "波兰",
    "countryPinyin": "bo lan",
    "phoneCode": "48",
    "countryCode": "PL",
    "enName": "Poland",
    "enFullName": "the Republic of Poland",
    "reg": "/^(\\+?48)? ?[5-8]\\d ?\\d{3} ?\\d{2} ?\\d{2}$/"
  }],
  "key": "B"
}, {
  "data": [{
    "countryName": "德国",
    "countryPinyin": "de guo",
    "phoneCode": "49",
    "countryCode": "DE",
    "enName": "Germany",
    "enFullName": "he Federal Republic of Germany",
    "reg": "/^(\\+?49[ \\.\\-])?([\\(]{1}[0-9]{1,6}[\\)])?([0-9 \\.\\-\\/]{3,20})((x|ext|extension)[ ]?[0-9]{1,4})?$/"
  }, {
    "countryName": "丹麦",
    "countryPinyin": "dan mai",
    "phoneCode": "45",
    "countryCode": "DK",
    "enName": "Denmark",
    "enFullName": "the Kingdom of Denmark",
    "reg": "/^(\\+?45)?(\\d{8})$/"
  }],
  "key": "D"
}, {
  "data": [{
    "countryName": "俄罗斯",
    "countryPinyin": "e luo si",
    "phoneCode": "7",
    "countryCode": "RU",
    "enName": "Russian Federation",
    "enFullName": "the Russian Federation",
    "reg": "/^(\\+?7|8)?9\\d{9}$/"
  }],
  "key": "E"
}, {
  "data": [{
    "countryName": "芬兰",
    "countryPinyin": "fen lan",
    "phoneCode": "358",
    "countryCode": "FI",
    "enName": "Finland",
    "enFullName": "the Republic of Finland",
    "reg": "/^(\\+?358|0)\\s?(4(0|1|2|4|5)?|50)\\s?(\\d\\s?){4,8}\\d$/"
  }, {
    "countryName": "法国",
    "countryPinyin": "fa guo",
    "phoneCode": "33",
    "countryCode": "FR",
    "enName": "France",
    "enFullName": "the French Republic",
    "reg": "/^(\\+?33|0)[67]\\d{8}$/"
  }],
  "key": "F"
}, {
  "data": [{
    "countryName": "捷克共和国",
    "countryPinyin": "jie ke gong he guo",
    "phoneCode": "420",
    "countryCode": "CZ",
    "enName": "Czech Republic",
    "enFullName": "the Czech Republic",
    "reg": "/^(\\+?420)? ?[1-9][0-9]{2} ?[0-9]{3} ?[0-9]{3}$/"
  }],
  "key": "J"
}, {
  "data": [{
    "countryName": "马来西亚",
    "countryPinyin": "ma lai xi ya",
    "phoneCode": "60",
    "countryCode": "MY",
    "enName": "Malaysia",
    "reg": "/^(\\+?6?01){1}(([145]{1}(\\-|\\s)?\\d{7,8})|([236789]{1}(\\s|\\-)?\\d{7}))$/"
  }, {
    "countryName": "美国",
    "countryPinyin": "mei guo",
    "phoneCode": "1",
    "countryCode": "US",
    "enName": "United States of America",
    "enFullName": "the United States of America",
    "reg": "/^(\\+?1)?[2-9]\\d{2}[2-9](?!11)\\d{6}$/"
  }],
  "key": "M"
}, {
  "data": [{
    "countryName": "挪威",
    "countryPinyin": "nuo wei",
    "phoneCode": "47",
    "countryCode": "NO",
    "enName": "Norway",
    "enFullName": "the Kingdom of Norway",
    "reg": "/^(\\+?47)?[49]\\d{7}$/"
  }],
  "key": "N"
}, {
  "data": [{
    "countryName": "葡萄牙",
    "countryPinyin": "pu tao ya",
    "phoneCode": "351",
    "countryCode": "PT",
    "enName": "Portugal",
    "enFullName": "the Portuguese Republic",
    "reg": "/^(\\+?351)?9[1236]\\d{7}$/"
  }],
  "key": "P"
}, {
  "data": [{
    "countryName": "日本",
    "countryPinyin": "ri ben",
    "phoneCode": "81",
    "countryCode": "JP",
    "enName": "Japan",
    "reg": "/^(\\+?81|0)\\d{1,4}[ \\-]?\\d{1,4}[ \\-]?\\d{4}$/"
  }],
  "key": "R"
}, {
  "data": [{
    "countryName": "沙特阿拉伯",
    "countryPinyin": "sha te a la bo",
    "phoneCode": "966",
    "countryCode": "SA",
    "enName": "Saudi Arabia",
    "enFullName": "the Kingdom of Saudi Arabia",
    "reg": "/^(!?(\\+?966)|0)?5\\d{8}$/"
  }],
  "key": "S"
}, {
  "data": [{
    "countryName": "西班牙",
    "countryPinyin": "xi ban ya",
    "phoneCode": "34",
    "countryCode": "ES",
    "enName": "Spain",
    "enFullName": "the Kingdom of Spain",
    "reg": "/^(\\+?34)?(6\\d{1}|7[1234])\\d{7}$/"
  }, {
    "countryName": "希腊",
    "countryPinyin": "xi la",
    "phoneCode": "30",
    "countryCode": "GR",
    "enName": "Greece",
    "enFullName": "the Hellenic Republic",
    "reg": "/^(\\+?30)?(69\\d{8})$/"
  }, {
    "countryName": "匈牙利",
    "countryPinyin": "xiong ya li",
    "phoneCode": "36",
    "countryCode": "HU",
    "enName": "Hungary",
    "enFullName": "the Republic of Hungary",
    "reg": "/^(\\+?36)(20|30|70)\\d{7}$/"
  }, {
    "countryName": "新西兰",
    "countryPinyin": "xin xi lan",
    "phoneCode": "64",
    "countryCode": "NZ",
    "enName": "New Zealand",
    "reg": "/^(\\+?64|0)2\\d{7,9}$/"
  }, ],
  "key": "X"
}, {
  "data": [{
    "countryName": "英国",
    "countryPinyin": "ying guo",
    "phoneCode": "44",
    "countryCode": "GB",
    "enName": "United Kingdom",
    "enFullName": "the United Kingdom of Great Britain and Northern Ireland",
    "reg": "/^(\\+?44|0)7\\d{9}$/"
  }, {
    "countryName": "印度",
    "countryPinyin": "yin du",
    "phoneCode": "91",
    "countryCode": "IN",
    "enName": "India",
    "enFullName": "the Republic of India",
    "reg": "/^(\\+?91|0)?[789]\\d{9}$/"
  }, {
    "countryName": "意大利",
    "countryPinyin": "yi da li",
    "phoneCode": "39",
    "countryCode": "IT",
    "enName": "Italy",
    "enFullName": "the Republic of Italy",
    "reg": "/^(\\+?39)?\\s?3\\d{2} ?\\d{6,7}$/"
  }, {
    "countryName": "越南",
    "countryPinyin": "yue nan",
    "phoneCode": "84",
    "countryCode": "VN",
    "enName": "Viet Nam",
    "enFullName": "the Socialist Republic of Viet Nam",
    "reg": "/^(\\+?84|0)?((1(2([0-9])|6([2-9])|88|99))|(9((?!5)[0-9])))([0-9]{7})$/"
  }],
  "key": "Y"
}, {
  "data": [{
    "countryName": "中国",
    "countryPinyin": "zhong guo",
    "phoneCode": "86",
    "countryCode": "CN",
    "reg": "/^(\\+?0?86\\-?)?1[345789]\\d{9}$/"
  }, {
    "countryName": "中国香港",
    "countryPinyin": "zhong guo xiang gang te bie xing zheng qu",
    "phoneCode": "852",
    "countryCode": "HK",
    "reg": "/^(\\+?852\\-?)?[569]\\d{3}\\-?\\d{4}$/"
  }, {
    "countryName": "中国澳门",
    "countryPinyin": "zhong guo ao men te bie xing zheng qu",
    "phoneCode": "853",
    "countryCode": "MO",
    "reg": "/^(\\+?853\\-?)?[6]([8|6])\\d{5}$/"
  }, {
    "countryName": "中国台湾",
    "countryPinyin": "tai wan",
    "phoneCode": "886",
    "countryCode": "TW",
    "reg": "/^(\\+?886\\-?|0)?9\\d{8}$/"
  }, ],
  "key": "Z"
}]

module.exports = {
  countryCodeData: countryCodeData
}