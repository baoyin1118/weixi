// 请求配置

// 请求token参数
const token_param = {
  token_url: "https://c2.yonyoucloud.com/iuap-api-auth/open-auth/selfAppAuth/getAccessToken",
  appkey: "484ffe477df64effb022374d36a90f24",
  appsecrect: "78f445f006ca4383a02545ee06c7882a"
}


// 请求路径
const path_request = 'https://c2.yonyoucloud.com/iuap-api-gateway/kuwm0ptf/yonbuilder/quoter/'; // 请求域名
const path_request_getWxOpenid = path_request + 'getWxOpenid'; // 获取用户id
const path_request_addWxAppUser = path_request + 'addWxAppUser'; // 添加微信小程序用户
const path_request_updateAppUser = path_request + "updateAppUser"; // 更新微信小程序用户
const path_request_queryAppUser = path_request + 'queryAppUser'; // 获取用户信息
const path_request_queryServiceQuote = path_request + "queryServiceQuote"; // 查询服务报价详情
const path_request_addQuoteLog = path_request + "addQuoteLog"; // 添加报价
const path_request_queryQuoteLog = path_request + "queryQuoteLog"; // 查询历史报价详情
const path_request_updateShareTimes = path_request + "updateShareTimes"; // 查询历史报价详情
const path_request_certificationUser = path_request + "certificationUser"; // 实名认证
const path_request_queryQuoCriteria = path_request + "queryQuoCriteria"; // 查询报价准则
const path_request_getModule = path_request + "getModule";//获取实施模块报价
const path_request_addssquotationlog =  path_request + "addSSQuotationLog";//保存实施报价
const path_request_getssquotationlog =  path_request + "getssQuotationLog";//查询实施报价
module.exports = {
  token_param: token_param,
  PATH_REQUEST_GETWXOPENID: path_request_getWxOpenid,
  PATH_REQUEST_ADDWXAPPUSER: path_request_addWxAppUser,
  PATH_REQUEST_UPDATEWXAPPUSER: path_request_updateAppUser,
  PATH_REQUEST_QUERYSERVICEQUOTE: path_request_queryServiceQuote,
  PATH_REQUEST_ADDQUOTELOG: path_request_addQuoteLog,
  PATH_REQUEST_QUERYQUOTELOG: path_request_queryQuoteLog,
  PATH_REQUEST_UPDATESHARETIMES: path_request_updateShareTimes,
  PATH_REQUEST_QUERYAPPUSER: path_request_queryAppUser,
  PATH_REQUEST_CERTIFICATIONUSER: path_request_certificationUser,
  PATH_REQUEST_QUERYQUOCRITERIA: path_request_queryQuoCriteria,
  PATH_REQUEST_GETMODULE:path_request_getModule,
  PATH_REQUEST_ADDSSQUOTATIONLOG:path_request_addssquotationlog,
  PATH_REQUEST_GETSSQUOTATIONLOG:path_request_getssquotationlog
}