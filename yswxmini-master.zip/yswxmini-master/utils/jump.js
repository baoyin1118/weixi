// 路由封装
const PAGE = require('../etc/basic');
// 跳转页面
function jumpPage(page, param){
  // var urldata = "../"+page+"/"+page;
  page = ('page_' + page).toUpperCase();
  var urldata = PAGE[page].path;
  if(param){
    var params = "";
    for(var key in param){
      params += ("&" + key + "=" + param[key]);
    }
    params.slice(1);
    urldata += "?" + params;
  }
  wx.navigateTo({
    url: urldata,
    success: function(){

    },
    fail: function(){
      console.error("=======跳转失败=========");
    }
  })
}

// 跳转tab
function jumpTab(page){
  // var url = "../"+tab+"/"+tab;
  page = ('page_' + page).toUpperCase();
  var url = PAGE[page].path;
  wx.switchTab({
    url: url,
    success: function(){

    },
    fail: function(){
      console.error();
    }
  })
}

module.exports = {
  jumpPage: jumpPage,
  jumpTab: jumpTab
}