/** 
 * new Date() ---> 转化为 年 月 日 时 分 秒
 * let date = new Date();
 * date: 传入参数日期 Date
 */
function formatTime(date) {
    var year = date.getFullYear()
    var month = date.getMonth() + 1
    var day = date.getDate()

    var hour = date.getHours()
    var minute = date.getMinutes()
    var second = date.getSeconds()


    return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatNumber(n) {
    n = n.toString()
    return n[1] ? n : '0' + n
}

/** 
 * 时间戳转化为年 月 日 时 分 秒 
 * number: 传入时间戳 
 * format：返回格式，支持自定义，但参数必须与formateArr里保持一致 
 */
function customFormatTime(number, format) {

    var formateArr = ['Y', 'M', 'D', 'h', 'm', 's'];
    var returnArr = [];

    var date = new Date(number);
    returnArr.push(date.getFullYear());
    returnArr.push(formatNumber(date.getMonth() + 1));
    returnArr.push(formatNumber(date.getDate()));

    returnArr.push(formatNumber(date.getHours()));
    returnArr.push(formatNumber(date.getMinutes()));
    returnArr.push(formatNumber(date.getSeconds()));

    for (var i in returnArr) {
        format = format.replace(formateArr[i], returnArr[i]);
    }
    return format;
}

//乘法函数，用来得到精确的乘法结果 
//说明：javascript的乘法结果会有误差，在两个浮点数相乘的时候会比较明显。这个函数返回较为精确的乘法结果。 
//调用：accMul(arg1,arg2) 
//返回值：arg1乘以arg2的精确结果 
function accMul(arg1, arg2) {
    var m = 0,
        s1 = arg1.toString(),
        s2 = arg2.toString();
    try {
        if (s1.split(".")[1] != undefined)
            m += s1.split(".")[1].length
    } catch (e) {}
    try {
        if (s2.split(".")[1] != undefined)
            m += s2.split(".")[1].length
    } catch (e) {}
    return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
}

//浮点数除法运算  
function accDiv(arg1, arg2) {
    var r1 = 0,
        r2 = 0,
        m, s1 = arg1.toString(),
        s2 = arg2.toString();
    try {
        if (s1.split(".")[1] != undefined)
            r1 = s1.split(".")[1].length;
    } catch (e) {}
    try {
        if (s2.split(".")[1] != undefined)
            r2 = s2.split(".")[1].length;
    } catch (e) {}
    m = Math.pow(10, Math.max(r1, r2));
    return (accMul(arg1, m)) / (accMul(arg2, m));
}

function accAdd(arg1, arg2) {
    var r1 = 0,
        r2 = 0,
        m, s1 = arg1.toString(),
        s2 = arg2.toString();
    try {
        if (s1.split(".")[1] != undefined)
            r1 = s1.split(".")[1].length;
    } catch (e) {}
    try {
        if (s2.split(".")[1] != undefined)
            r2 = s2.split(".")[1].length;
    } catch (e) {}
    m = Math.pow(10, Math.max(r1, r2));
    return (accMul(arg1, m) + accMul(arg2, m)) / m;
}

function Subtr(arg1, arg2) {
    var r1 = 0,
        r2 = 0,
        m, n, s1 = arg1.toString(),
        s2 = arg2.toString();
    try {
        if (s1.split(".")[1] != undefined)
            r1 = s1.split(".")[1].length;
    } catch (e) {}
    try {
        if (s2.split(".")[1] != undefined)
            r2 = s2.split(".")[1].length;
    } catch (e) {}
    m = Math.pow(10, Math.max(r1, r2));
    //last modify by deeka
    //动态控制精度长度
    n = (r1 >= r2) ? r1 : r2;
    return (accMul(arg1, m) - accMul(arg2, m)) / m;
}

// 节流
const throttle = (fn, wait = 0) => {
    let lastTime = null
    return function () {
        let curTime = new Date()
        // 距离下次触发fn还需等待的时间(如果没有lastTime说明是第一次，可以表示执行，即等待时间为0
        let remainTime = lastTime ? wait - (curTime - lastTime) : 0
        if (remainTime <= 0 || remainTime > wait) {
            lastTime = curTime
            return fn.apply(this, arguments)
        }
    }
}

module.exports = {
    formatTime: formatTime,
    customFormatTime: customFormatTime,
    accMul: accMul,
    accAdd: accAdd,
    accDiv:accDiv,
    throttle: throttle
}