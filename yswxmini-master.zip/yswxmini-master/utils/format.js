// 格式化模板

// 入口函数
function formatTable(type, res) {
  var p = new Promise(function (resolve, reject) {
    switch (type) {
      case 'trade':
        var data = formatTradeTable(res);
        resolve(data);
        break;
      case 'tradehistory':
        var data = formatTradeHistoryTable(res);
        resolve(data);
        break;
      case 'count':
        var data = formatCountTable(res);
        resolve(data);
        break;
      case 'history':
        var data = formatHistoryTable(res);
        resolve(data);
        break;
      case 'print':
        var data = formatPrintTable(res);
        resolve(data);
        break;
      case 'userinfo':
        var data = formatUserInfoPost(res);
        resolve(data);
        break;
      case 'infolist':
        var data = formatInfoList(res);
        resolve(data);
        break;
      case 'rules':
        var data = formatRules(res);
        resolve(data);
        break;
     case 'dayCount':
      var data = formatDayCountTable(res)
      resolve(data);
      break;
      default:
        console.log("【utils/format】type is wrong!");
        reject("fail")
        break;
    }
  });
  return p;
}

// trade页面模板
async function formatTradeTable(res) {
  var table = [];
  var obj = {};
  var objitem = {};
  // 去掉除服务外的
  for (var i = res.length - 1; i >= 0; i--) {
    if (res[i].isService != "true" && res[i].isService != true) {
      res.splice(i, 1);
    }
  }
  // 同模块放在一起
  obj = await settabledata(res[0]);
  table.push(obj);
  for (var i = 1; i < res.length; i++) {
    for (var j = 0; j < table.length; j++) {
      if (res[i].serviceClassName == table[j].name) {
        objitem = await setlistdata(res[i]);
        table[j].list.push(objitem);
        break;
      } else {
        if (j == table.length - 1) {
          obj = await settabledata(res[i]);
          table.push(obj);
          break;
        }
      }
    }
  };
  return table;
}

async function settabledata(res) {
  var obj = {
    // head: ["模块", "价格", "选购"],
    head: ["模块", "人天","总价", "选购"],
    name: res.serviceClassName,
    id: res.serviceClassId,
    is_by_user: res.is_by_user || "false",
    user: res.is_by_user == "true" ? (res.userNum || res.include_licenses || 1) : null,
    unit_price: res.unit_price || 0,
    include_licenses: res.is_by_user == "true" ? (res.include_licenses || 0) : null,
    list: [await setlistdata(res)]
  };
  return obj;
}

function setlistdata(res) {
  var obj = {
    name: res.name,
    price: res.base_price || 0, // 基础价格
    unit_price: res.unit_price || 0, // 单价
    base_price: res.base_price || 0,
    code: res.code,
    productId: res.productId,
    id: res.id,
    isService: true,
    is_alone: res.is_alone, // 是否单独计算用户价格
    serviceIncludeLicenses: res.serviceIncludeLicenses || 0, // 服务包含许可数
    serviceIsByUser: res.serviceIsByUser, // 是否按用户计算
    serviceUnitPrice: res.serviceUnitPrice || 0 // 服务用户单价
  };
  return obj;
}

// tradeHistory
function formatTradeHistoryTable(tables) {
  var table = tables.tablename;
  var check = tables.checktable;
  var org = false;
  check = JSON.parse(check.details).data;
  check.forEach((item, idx) => {
    if (item.name == '多组织') {
      org = true;
    }
    table.forEach((it, i) => {
      if (item.serviceClassId == it.id) {
        var num = it.list.findIndex(v => v.code == item.code);
        if (num >= 0) {
          table[i].list[num].checked = true;
          table[i].user = item.userNum;
        } else {
          console.log("暂不提供", item.name, "服务");
        }
      }
    })
  });
  var res = {
    table: table,
    org: org
  }
  // console.log(res.table);
  return res;
}

//计算人员金额
function formatDayCountTable(datas) {
  var table = datas;
  var data = [];
  var res = [];
  var saleparam = 0;
  table.forEach((item, idx) => {
    var arr = [];
    item.list.forEach((it, i) => {
      if (it.checked) {
        arr.push(it);
        if(it.menu == "B2C订单中心"){
          saleparam += 1;
        }
        if(it.menu == "零售管理"){
          saleparam += 10;
        }
      }
      
    })
    item.list = arr;
    item.saleparam = saleparam;
    if (arr.length) {
      data.push(item)
      res.push(item)
    }
  });
  return res;
}  

// count函数模板
function formatCountTable(datas) {
  var table = datas;
  var data = [];
  table.forEach((item, idx) => {
    var arr = [];
    item.list.forEach((it, i) => {
      if (it.checked) {
        arr.push(it);
      }
    })
    item.list = arr;
    if (arr.length) {
      data.push(item);
    }
  });
  // console.log(data);
  var res = [];
  var obj = {}
  data.forEach((item, idx) => {
    obj = {};
    obj.is_by_user = item.is_by_user;
    obj.userNum = item.is_by_user == "true" ? item.user : null;
    obj.include_licenses = item.is_by_user == "true" ? item.include_licenses : null;
    obj.serviceClassId = item.id;
    obj.serviceClassName = item.name;
    for (var i = 0; i < item.list.length; i++) {
      obj.unit_price = item.list[i].unit_price;
      obj.base_price = item.list[i].price;
      obj.name = item.list[i].name;
      obj.code = item.list[i].code;
      obj.productId = item.list[i].productId;
      obj.id = item.list[i].id;
      obj.isService = item.list[i].isService;
      obj.is_alone = item.list[i].is_alone;
      obj.serviceIncludeLicenses = item.list[i].serviceIncludeLicenses;
      obj.serviceIsByUser = item.list[i].serviceIsByUser;
      obj.serviceUnitPrice = item.list[i].serviceUnitPrice;
      var objdata = JSON.parse(JSON.stringify(obj))
      res.push(objdata);
    }
  });
  return res;
}

// history
function formatHistoryTable(table) {
  var res = [];
  table.forEach((item, idx) => {
    var obj = {};
    obj.historyid = item.quotationid;
    obj.id = item.id;
    obj.name = item.name;
    obj.time = item.quotation_time;
    obj.overtime = item.quotation_time.split("-");
    obj.overtime[0] = parseInt(obj.overtime[0]) + parseInt(item.purchase_period);
    obj.overtime = obj.overtime.join("-");
    obj.price = item.amount_of_money;
    // obj.type = 'newTrade';
    res.push(obj);
  })
  res.reverse();
  return res;
}

// print
async function formatPrintTable(table) {
  var result = {
    tablename: [],
    tableother: [],
    org: false,
    overtime: ''
  }
  // console.log(table);
  var year = table.purchase_period;
  var fee = parseInt(table.service_fee);
  result.overtime = table.quotation_time.split("-");
  result.overtime[0] = parseInt(result.overtime[0]) + parseInt(table.purchase_period);
  result.overtime = result.overtime.join("-");
  var count = table.amount_of_money;
  var recount = 0;
  table = JSON.parse(table.details).data;
  // console.log(table);
  var res = await formatTradeTable(table);
  // tablename
  // console.log(res);
  var tablename = res.map((item, idx) => {
    var count = 0;
    var usercount = 0;
    var basecount = 0;
    item.head = ["服务", "价格"];
    var s = false; // 判断是否有服务根据模块用户单价计算
    item.list = item.list.map((it, i) => {
      // 判断多组织
      if (it.name == '多组织') {
        result.org = true;
      }
      // basecount
      basecount += it.base_price;
      // usercount
      var userprice = 0;
      if (it.serviceIsByUser == 'true') {
        if (it.is_alone == 'true') {
          let usernum = item.user - it.serviceIncludeLicenses;
          if (usernum < 0) usernum = 0;
          userprice = usernum * it.serviceUnitPrice;
        } else {
          s = true;
        }
      }
      usercount += userprice;
      it.price = it.base_price + userprice;
      count += it.price;
      return it;
    });
    if (item.is_by_user == 'true' && s) {
      count += (item.user - item.include_licenses) * (item.unit_price || 0);
    }
    item.price = count;
    return item;
  });
  result.tablename = tablename;
  // tableother
  var otherrules = {
    name: "其他标准",
    head: ["标准", "数量"],
    list: [{
      name: "购买年限",
      price: year
    }, {
      name: "实施费用",
      price: fee
    }]
  };
  var othercount = {
    name: "总计",
    head: ["模块", "用户数", "总价"]
  }
  othercount.list = result.tablename.map((item, idx) => {
    var obj = {
      name: item.name,
      user: item.user || '-',
      price: item.price
    }
    // console.log(item.price);
    recount += item.price;
    return obj;
  })
  // var obj = {
  //   name: "实施费用",
  //   price: fee
  // }
  // othercount.list.push(obj);
  recount = (recount * year) + fee;
  // console.log("后台保存价格：", count, "核实价格", recount);
  result.tableother.push(othercount);
  result.tableother.push(otherrules);
  result.count = count;
  result.recount = recount;
  return result;
}

function formatUserInfoPost(userInfo) {
  var obj = {};
  obj.userInfo = userInfo;
  obj.nickname = userInfo.nickName;
  obj.avatarUrl = userInfo.avatarUrl;
  obj.gender = userInfo.gender + ''; // 性别 0：未知、1：男、2：女
  obj.province = userInfo.province;
  obj.city = userInfo.city;
  obj.country = userInfo.country;
  // console.log(obj);
  return obj;
}

// formatInfoList
function formatInfoList(info) {
  var res = [];
  var obj = {
    name: '基本信息',
    list: [{
      name: '昵称',
      val: info.nickname
    }, {
      name: '手机号',
      val: info.phone_num
    }, {
      name: '地区',
      val: info.province + " " + info.city
    }, ]
  };
  res.push(obj);
  obj = {
    name: '实名信息',
    list: [{
      name: '身份证号',
      val: info.ic_number
    }, {
      name: '生日',
      val: info.ic_birth
    }, {
      name: '地址',
      val: info.ic_address
    }]
  };
  res.push(obj);
  return res;
}

// formatRules
function formatRules(data) {
  var res = data;
  res = res.map((item) => {
    return {
      id: item.productId,
      head: item.name,
      text: item.content
    }
  })
  return res;
}

module.exports = {
  formatTable: formatTable
}