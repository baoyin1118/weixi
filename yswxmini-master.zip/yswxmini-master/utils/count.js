//计算

const {
  accMul,
  accAdd,
  accDiv
} = require("./util");


//计算人天和实施金额
function calculateWorkday(datas ){
  
  const { biptype } = datas;
  
  console.log("calculateWorkday",datas);
  var result = {};
  var hasb2c = false;
  var haspos = false;
  var saleRomoteday = 0;
  var saleOnsiteday = 0;
  var remoteDay = 0;
  var onsiteDay = 0;
  var baonsiteDay = 0;
  var saremoteDay = 0;
  var saleSaremoteDay = 0;
  var saleBaonSiteDay = 0;
  var businessRadio = 1;
  var orgRadio = 1;
  var bipworkday = 0;
  function getValueOrDefault(value, defaultValue = 0) {
    return value !== undefined ? value : defaultValue;
  }
  
  datas.result.map((d)=>{
    d.list.forEach((e,idx) => {
      if(e.menu == "B2C订单中心"){
        hasb2c = true;
      }
      if(e.menu == "零售管理"){
        saleRomoteday = getValueOrDefault(e.remote_day,0);
        saleOnsiteday = getValueOrDefault(e.on_site_day, 0);
        saleSaremoteDay = getValueOrDefault(e.saremote_day, 0);
        saleBaonSiteDay = getValueOrDefault(e.baon_site_day, 0);
        haspos = true;
      }
      remoteDay = accAdd(getValueOrDefault(e.remote_day,0),remoteDay);
      onsiteDay = accAdd(getValueOrDefault(e.on_site_day, 0),onsiteDay);
      saremoteDay = accAdd(getValueOrDefault(e.saremote_day, 0),saremoteDay);
      baonsiteDay = accAdd(getValueOrDefault(e.baon_site_day, 0),baonsiteDay);
      bipworkday = accAdd(getValueOrDefault(e.bipyyg_day, 0),bipworkday);

    });
  })
  //店铺每增加1个，远程人天+2
  if(datas.shop_num > 1 && hasb2c){
    remoteDay = accAdd(remoteDay,accMul((datas.shop_num-1),2));
    saremoteDay = accAdd(saremoteDay,accMul((datas.shop_num-1),2));
  }

  //零售管理  pos 
  if(datas.pos_num > 50 && haspos){
      let radio = 1;
      if(datas.pos_num > 50 && datas.pos_num <= 300){
        radio = 2;
      }else{//300以上
        radio = 4;
      }
      remoteDay = accAdd(remoteDay,accMul((radio-1),saleRomoteday));
      onsiteDay = accAdd(onsiteDay,accMul((radio-1),saleOnsiteday));
      saremoteDay = accAdd(saremoteDay,accMul((radio-1),saleSaremoteDay));
      baonsiteDay = accAdd(baonsiteDay,accMul((radio-1),saleBaonSiteDay));

  }
  //多业态
  if(datas.business_type == "是"){
    remoteDay = accMul(remoteDay,1.5);
    onsiteDay = accMul(onsiteDay,1.5);
    saremoteDay = accMul(saremoteDay,1.5);
    baonsiteDay = accMul(baonsiteDay,1.5);
    businessRadio = 1.5;
  }
  //多组织 2-5组织*1.4；6-10组织*1.5；11-20组织*1.6；21-50组织*2；51以上单独评估
  if(datas.org_num > 1){
      let radio = 1;
      if(datas.org_num >=2  && datas.org_num <= 5){
        radio = 1.4;
      }else if(datas.org_num >=6  && datas.org_num <= 10){
        radio = 1.5;
      }else if(datas.org_num >=11  && datas.org_num <= 20){
        radio = 1.6;
      }else if(datas.org_num >=21  && datas.org_num <= 50){
        radio = 2;
      }
    
      onsiteDay = accAdd(onsiteDay,accMul(onsiteDay, (radio-1)));
      remoteDay = accAdd(remoteDay,accMul(remoteDay,(radio-1)));
      baonsiteDay = accAdd(baonsiteDay,accMul(baonsiteDay, (radio-1)));
      saremoteDay = accAdd(saremoteDay,accMul(saremoteDay,(radio-1)));
      orgRadio = radio;
  }
  let onsiteprice = 2500;
  let remoteprice = 1200;

  onsiteDay = formateNum(onsiteDay);
  //历史凭证数，2500 增加一个远程人天，向上取整
  let voucher_romoteday = 0; 
  if(datas.voucher_num > 1){
    voucher_romoteday = accDiv(datas.voucher_num,2500);
    voucher_romoteday=Math.ceil(voucher_romoteday);
  }
  
  remoteDay = formateNum(accAdd(remoteDay,voucher_romoteday));
  saremoteDay = formateNum(accAdd(saremoteDay,voucher_romoteday));

  console.log("===>",onsiteDay,remoteDay);
  console.log("===>",baonsiteDay,saremoteDay);
  
  if (biptype === "否" || biptype === "") {
    result.total = accAdd(accMul(onsiteDay,onsiteprice),accMul(remoteDay,remoteprice));
    result.workday = accAdd(onsiteDay,remoteDay);
    result.onsiteDay = onsiteDay;
    result.remoteDay = remoteDay;
    console.log(biptype);
  } else if (biptype === "是") {
    result.total = accAdd(accMul(baonsiteDay,onsiteprice),accMul(saremoteDay,remoteprice));
    result.workday = accAdd(baonsiteDay,saremoteDay);
    result.baonsiteDay = baonsiteDay;
    result.saremoteDay = saremoteDay;
    result.bipworkday = bipworkday;
    console.log(biptype);
  }


  if(datas.result.length>0){
    let dataResult = datas.result;
    let checkedlist = [];
    for(let i in dataResult){
      for(let j in dataResult[i].list){
        checkedlist.push(dataResult[i].list[j]);
      }
    }
    result.saleparam = dataResult[0].saleparam;
    result.checkedlist = checkedlist;
    result.hasb2c = hasb2c;
    result.haspos = haspos;
    result.orgnum = datas.org_num;
    result.businesstype = datas.business_type;
    result.biptype = datas.biptype;
    result.shopnum = datas.shop_num;
    result.posnum = datas.pos_num;
    result.remoteprice = remoteprice;
    result.onsiteprice = onsiteprice;
  }else{
    result.saleparam = 0;
  }
  result.businessRadio = businessRadio;
  result.orgRadio = orgRadio;
  return result;
}

//格式化数字  0.5 以下取整 0.5以上取0.5 
function formateNum(num){
  let i = parseInt(num);
  let d = num - i ;
  if(d < 0.50){
    return i;
  }else{
    return accAdd(i,0.5);
  }
}

//格式化数字  四舍五入
function formateNumRound(num){
  let i = parseInt(num);
  let d = num - i ;
  if(d < 0.50){
    return i;
  }else{
    return accAdd(i,1);
  }
}

// 入口
function Calculate(datas) {
  var p = new Promise(function (res, rev) {
    var count = countTable(datas);
    res(count);
  });
  return p;
}

// 计算表格
function countTable(datas) {
  console.log("datas", datas);
  //分模块计算
  var total = 0;
  var except_user = [];
  datas.result.map((data) => {
    //获取数据
    const {
      serviceClassId,
      serviceIsByUser,
      serviceUnitPrice,
      is_alone,
      serviceIncludeLicenses
    } = data;
    if (is_alone === "true") {
      data.is_by_user = serviceIsByUser;
      data.include_licenses = serviceIncludeLicenses;
      data.unit_price = serviceUnitPrice
    } else if (except_user.includes(serviceClassId)) {
      data.is_by_user = "false";
    } else {
      // 当前模块用户设为已计算
      except_user.push(serviceClassId);
    }
    total += CalculateByServiceClass(data);
  });
  // 获取使用年限
  let purchase_period = (datas.purchase_period > 0 ? datas.purchase_period : 1)
  // 获取实施费用
  let service_fee = (datas.service_fee > 0 ? datas.service_fee : 0);
  total = accAdd(accMul(total, purchase_period), service_fee);
  // console.log("最终报价：", total);
  return total;
}

function CalculateByServiceClass(data) {
  //判断是否按用户
  const is_by_user = data.is_by_user;
  // 用户价格
  var userPrice = 0;
  //按用户计算
  if (is_by_user == "true") {
    // 拿到单价
    const unit_price = data.unit_price;
    // 拿到用户数
    const userNum = data.userNum;
    // 拿到用户许可数
    const include_licenses = data.include_licenses == undefined ? 0 : data.include_licenses;
    // 计算实际用户数 最少用户为0
    const userTotal = (userNum - include_licenses) > 0 ? (userNum - include_licenses) : 0;
    // 计算用户价
    userPrice = accMul(userTotal, unit_price);
  }
  //获取基础单价
  let base_price = data.base_price;

  //计算报价
  return accAdd(base_price, userPrice);
}

//销售报价计算
function calculateSale(item){
  let money = 0;
  //类型1计算
  if(item.sale_calcu_type == "1"){
    if(item.price != undefined){
      money+=item.price;
    }
    let priceArr = item.price_arr;
    if(item.xks!=undefined && priceArr!= undefined && priceArr.length > 0) {
      let xks = parseInt(item.xks);
      let ladder = 0;
      for(let i = 0;i < priceArr.length;i++){
        let left = priceArr[i].left;
        let right = priceArr[i].right;
        let ladder_price = priceArr[i].price;
        if(xks >= left && (right == undefined || xks<= right)){
          if(i == 0){
            ladder += (xks * ladder_price);
          }else{
            ladder += ((xks-left+1) * ladder_price);
          }
          break;
        }else{
          ladder+=(right * ladder_price);
        }
      }
      money += ladder;
    }
  }else if(item.sale_calcu_type=="2"){
    if(item.price != undefined){
      money+=item.price;
    }
    let license = item.default_license;
    let priceArr = item.price_arr;
    if(item.xks != undefined && priceArr != undefined && priceArr.length > 0) {
      let xks = parseInt(item.xks);
      if(xks > license){
        let ladder = 0;
        
        for(let  i = 0;i < priceArr.length;i++){
          let p = priceArr[i];
          let pp = p.price;
          if(xks >= p.left && (p.right == undefined || xks<= p.right)){
              if(i == 0){
                ladder += ((xks-license)*pp);
              }else{
                ladder += ((xks - priceArr[i-1].right)*pp);
              }
              break;
          }else{
            ladder += (p.right - license)*pp;
          }
        }
        money += ladder;
        }
      }
  }else if(item.sale_calcu_type=="3"){
    if(item.price != undefined){
      money+=item.price;
    }
  }else if(item.sale_calcu_type=="4"){
    if(item.price != undefined && item.xks == "1"){
      money+=item.price;
    }
  }else if(item.sale_calcu_type=="5"){
    console.log("====>",item);
    if(item.xks != undefined){
      let xks = parseInt(item.xks);
      let priceArr = item.price_arr;
      for(let i =0;i < priceArr.length;i++){
        let p = priceArr[i];
        if(xks >= p.left && (p.right == undefined || xks <= p.right)){
          money+=p.price;
          break;
        }
      }
    }

  }else if(item.sale_calcu_type=="6"){
    //基础价格+购买许可数*单价
    if(item.price != undefined){
      money+=item.price;
    }
    let xks = parseInt(item.xks);
    let priceArr = item.price_arr;
    let p = priceArr[0].price;
    money += xks*p;

  }else if(item.sale_calcu_type=="7"){
    //免费
  }else if(item.sale_calcu_type=="8"){
    let priceArr = item.price_arr;
    //许可数 * 对应阶梯单价，不累计
    if(item.xks != undefined  && priceArr != undefined && priceArr.length > 0){
      let xks = parseInt(item.xks);
      for(let i =0;i < priceArr.length;i++){
        let p = priceArr[i];
        if(xks >= p.left && (p.right == undefined || xks <= p.right)){
          money += xks*p.price;
          break;
        }
      }  
    }
  }
  if(!money){
    money = 0;
  }
  return formateNumRound(money);
}

module.exports = {
  Calculate: Calculate,
  calculateWorkday:calculateWorkday,
  CalculateByServiceClass: CalculateByServiceClass,
  calculateSale:calculateSale
}
