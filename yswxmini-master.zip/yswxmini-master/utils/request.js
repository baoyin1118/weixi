const {
    token_param
} = require("../etc/request");
const {
    getToken
} = require("./token");

/**
 * @desc    API请求接口类封装
 */

/**
 * POST请求API
 * @param  {String}   url         接口地址
 * @param  {String}   token       请求接口时的Token
 * @param  {Object}   params      请求的参数
 * @param  {Object}   sourceObj   来源对象
 * @param  {Function} successFun  接口调用成功返回的回调函数
 * @param  {Function} failFun     接口调用失败的回调函数
 * @param  {Function} completeFun 接口调用结束的回调函数(调用成功、失败都会执行)
 */
function requestPostApi(url, params, successFun, failFun, completeFun, sourceObj) {
    console.log(url,params) 
    requestApi(url, params, 'POST', sourceObj, successFun, failFun, completeFun)
}

/**
 * GET请求API
 * @param  {String}   url         接口地址
 * @param  {String}   token       请求接口时的Token
 * @param  {Object}   params      请求的参数
 * @param  {Object}   sourceObj   来源对象
 * @param  {Function} successFun  接口调用成功返回的回调函数
 * @param  {Function} failFun     接口调用失败的回调函数
 * @param  {Function} completeFun 接口调用结束的回调函数(调用成功、失败都会执行)
 */
function requestGetApi(url, params, successFun, failFun, completeFun, sourceObj) {
    requestApi(url, params, 'GET', sourceObj, successFun, failFun, completeFun)
}

/**
 * 请求API
 * @param  {String}   url         接口地址
 * @param  {Object}   params      请求的参数
 * @param  {String}   method      请求类型
 * @param  {Object}   sourceObj   来源对象
 * @param  {Function} successFun  接口调用成功返回的回调函数
 * @param  {Function} failFun     接口调用失败的回调函数
 * @param  {Function} completeFun 接口调用结束的回调函数(调用成功、失败都会执行)
 */
function requestApi(url, params, method, sourceObj, successFun, failFun, completeFun) {
    var contentType = 'application/json';
    gettoken().then((token) => {
        wx.request({
            url: url + '?access_token=' + token.access_token,
            method: method,
            data: params,
            header: {
                'Content-Type': contentType,
                'API-Authorization': token,
                'ADMIN-Authorization': token,
            },
            success: function (res) {
                typeof successFun == 'function' && successFun(res.data, sourceObj);
            },
            fail: function (res) {
                typeof failFun == 'function' && failFun(res.data, sourceObj)
            },
            complete: function (res) {
                typeof completeFun == 'function' && completeFun(res.data, sourceObj)
            }
        })
    })
}

function gettoken() {
    return new Promise((resolve, reject) => {
        var token = wx.getStorageSync("token_data") ;
        var time = new Date().getTime();
        if (token && token.expire > time) {
            // // 超时重新获取token
            if (token.expire <= time) {
                getToken(token_param).then((res, rej) => {
                    res = res.data;
                    wx.getStorage({
                        key: 'token_data',
                        success: function (r) {
                           
                            resolve(r.data);
                        }
                    });
                });
            }
            resolve(token);
        } else {
            // 首次获取token
            getToken(token_param).then((res, rej) => {
                res = res.data;
                wx.getStorage({
                    key: 'token_data',
                    success: function (r) {
                        
                        resolve(r.data);
                    }
                });
            });
        }
    });
}

module.exports = {
    requestPostApi: requestPostApi,
    requestGetApi: requestGetApi
}