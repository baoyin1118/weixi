const {
  HmacSHA256
} = require('./crypto-js/mycry.js');
const Base64 = require('./crypto-js/enc-base64.js');
module.exports = {
  /**
   * 获取token
   */
  getToken: function (data) {
    // 获取token的url
    const token_url = data.token_url;
    // appkey
    const appkey = data.appkey;
    // appsecret
    const appsecrect = data.appsecrect;

    // 当前时间戳
    let timestamp = new Date().getTime();
    const secrectdata = 'appKey' + appkey + 'timestamp' + timestamp;
    const base64 = Base64.stringify(HmacSHA256(secrectdata, appsecrect));

    // 获取签名
    const signature = encodeURIComponent(base64);
    const requestUrl = token_url + '?appKey=' + appkey + '&timestamp=' + timestamp + '&signature=' + signature;

    // request同步请求
    return new Promise((resolve, reject) => {
      wx.request({
        url: requestUrl,
        method: 'GET',
        header: {
          'Content-Type': 'application/json'
        },
        success: function (res) {
          // 如果成功
          if (res.data.code == "00000") {

            //设置过期时间比实际过期时间提前五分钟
            const expire = new Date().getTime() + (res.data.data.expire * 1000 - 300000);
            var expireLocalString = new Date(expire).toLocaleString();

            // 处理后的token结果集
            const token_data = {
              expire: expire,
              expireLocalString: expireLocalString,
              access_token: res.data.data.access_token
            }

            // 微信全局存储
            wx.setStorage({
              data: token_data,
              key: 'token_data',
            });
            resolve(res.data)
          } else {
            reject(res.data);
          }
        },
        fail: function (err) {
          reject(err);
        },
      });
    });
  }
}