const {
  PATH_REQUEST_GETSSQUOTATIONLOG
} = require("../../etc/request");
// pages/history.js

const {
  TEMPLATE_HISTORY
} = require("../../etc/template");
const {
  formatTable
} = require("../../utils/format");
const {
  requestGetApi,
  requestPostApi
} = require("../../utils/request");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: [],
    type: 'list', // list为列表形式 choose为多选形式
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var wxid = wx.getStorageSync("openid");
    if (wxid) {
      requestPostApi(PATH_REQUEST_GETSSQUOTATIONLOG, {
        user: wxid
      }, (res) => {
        console.log("records,onLoad",res);
        if (res.code == 200) {
          if (res.data) {
            res = res.data.result;
            let arr = [];
            res.forEach(e =>{
                let v = {};
                v.time = e.createTime;
                v.name = e.name;
                v.total = e.total;
                v.id = e.id;
                arr.push(v);
            });
            that.setData({
                data:arr
            });
            // formatTable('history', res).then((res) => {
            //   // console.log(res);
            //   that.setData({
            //     data: res
            //   })
            // })
          } else {
            wx.showToast({
              title: '暂无历史记录',
              icon: 'none'
            })
          }
        } else {
          wx.showToast({
            title: res.code,
            icon: 'none'
          })
        };
      })
    } else {
      console.log("无用户id请登录");
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  goTrade: function (e) {
    var num = e.currentTarget.id.split("_")[1];
    // console.log(e, this.data.data[num]);
    var type = this.data.data[num].type;
    var historyid = this.data.data[num].historyid;
    var id = this.data.data[num].id;
    var urldata = '?type=' + type + '&historyid=' + historyid + '&id=' + id;
    wx.navigateTo({
      url: '../trade/trade' + urldata
    })
  },
  goPrint: function (e) {
    var num = e.currentTarget.id.split("_")[1];
    console.log(e, this.data.data[num]);

    var type = this.data.data[num].type;
    var id = this.data.data[num].id;
    var urldata = '?type=' + type + '&id=' + id;
    wx.navigateTo({
      url: '../record/record' + urldata
    })
  },
  //选中进入详情页
  oneSelect: function (e) {
    if (this.endTime - this.startTime >= 350) {
      return;
    }
    if (this.data.type == 'list') {
      console.log("oneSelect",e);
      this.goPrint(e);
    } else {
      var num = e.currentTarget.id.split("_")[1];
      console.log(num);
      this.changeDom(num);
    }
  },
  // 长按事件
  multiSelect: function (e) {
    this.setData({
      type: 'choose'
    });
    var num = e.currentTarget.id.split("_")[1];
    console.log(num);
    this.changeDom(num);
  },
  // 选中dom变化
  changeDom: function (id) {
    var arr = this.data.data;
    arr[id].checked = arr[id].checked ? false : true;
    this.setData({
      data: arr
    })
  },
  // 触摸开始
  bindTouchStart: function (e) {
    this.startTime = e.timeStamp;
  },
  // 触摸结束
  bindTouchEnd: function (e) {
    this.endTime = e.timeStamp;
  },
})