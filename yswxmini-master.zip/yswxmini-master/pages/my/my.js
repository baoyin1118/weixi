var app = getApp();
const {
    PATH_REQUEST_QUERYQUOTELOG,
    PATH_REQUEST_UPDATEWXAPPUSER
} = require("../../etc/request");
const {
    formatTable
} = require("../../utils/format");
const {
    jumpTab,
    jumpPage
} = require("../../utils/jump");
const {
    requestPostApi
} = require("../../utils/request");

Page({
    data: {
        userName: "暂未获取",
        userAvatar: "../../images/header.png",
        isLogin: -1,
        length: 0,
        logNum: 0
    },
    onLoad: function name(params) {},
    onShow: function () {
        this.initMyInfo();
    },
    // init
    initMyInfo: function () {
        var that = this;
        var islogin = app.globalData.user_status;
        that.setData({
            isLogin: islogin
        })
        if (islogin == 1) {
            // that.getlogNum();
            // app.getUser().then((res) => {
            //     console.log(res);
            //     if (res) {
            //         app.globalData.userinfo = res;
            //         that.setData({
            //             userName: res.nickname || '暂未获取',
            //             userAvatar: res.avatarUrl || '../../images/header.png',
            //         });
            //         that.getlogNum();
            //     }
            // })
        }
    },
    // 跳转-报价记录
    goHistory: function () {
        if (app.globalData.user_status == 1 && app.globalData.enable == 1) {
            // jumpPage('history');
            jumpPage('records');
        } else if (app.globalData.user_status == 1 && app.globalData.enable != 1) {
            wx.showToast({
                title: app.globalData.user_status + app.globalData.enable + '您没有访问权限 请联系管理员授权',
                icon: 'none'
            })
        } else {
            wx.navigateTo({
                url: '../login/login',
            })
        }
    },
  
    // 跳转—index首页
    goPricetab: function () {
        jumpTab("index");
    },
    // 跳转-userinfo
    goUserInfo: function () {
        if (app.globalData.user_status == 1) {
            jumpPage('userinfo');
        } else {
            wx.showToast({
                title: app.globalData.user_status + app.globalData.enable + '请您激活账户',
                icon: 'none'
            })
            wx.navigateTo({
                url: '../login/login',
            })
        }
    },
    // 获取报价数量
    getlogNum: function () {
        var that = this;
        var openid = wx.getStorageSync("openid");
        requestPostApi(PATH_REQUEST_QUERYQUOTELOG, {
            userid: openid
        }, (res) => {
            if (res.code == 200 && res.data) {
                res = res.data.result;
                that.setData({
                    logNum: res.length
                })
            } else {
                wx.showToast({
                    title: res.code + '获取报价数量错误',
                })
            }
        })
    },
    // 点击头像获取授权
    getUserInfo: function () {
        var that = this;
        if (this.data.isLogin <= 0) {
            jumpPage('login');
        } else {
            if (!app.globalData.userinfo) {
                app.authUserInfo();
                that.initMyInfo();
            } else {
                app.getUserInfo();
                that.initMyInfo();
            }
        }
    },
   
});