const {
    PATH_REQUEST_ADDWXAPPUSER,
    PATH_REQUEST_UPDATEWXAPPUSER
} = require("../../etc/request");
const {
    formatTable
} = require("../../utils/format");
const {
    requestPostApi
} = require("../../utils/request");
const {
    jumpTab
} = require("../../utils/jump")
var app = getApp();

Page({
    data: {
        phonecode: "86", // 国际区号
        phoneno: "", // 手机号
        reg: '/^(\\+?0?86\\-?)?1[345789]\\d{9}$/', // 手机正则判断
        company: "", // 公司
        username: "", // 姓名
        vcode: "", // 输入验证码
        buttonDisable: !1, // 控制按钮点击事件
        verifyCodeTime: "生成随机码", // 按钮文本
        code: "" // 随机验证码
    },
    // 绑定公司input
    usernameInputEvent: function (e) {
        this.setData({
            username: e.detail.value
        });
    },
    // 绑定公司input
    companyInputEvent: function (e) {
        this.setData({
            company: e.detail.value
        });
    },
 
    // 绑定手机国际区号
    mobileChooseEvent: function (params) {
        wx.navigateTo({
            url: '../phonecode/phonecode',
        })
    },
    // 绑定手机input
    mobileInputEvent: function (e) {
        this.setData({
            phoneno: e.detail.value
        });
    },
    // 获取验证码btn 添加获取验证码请求
    verifyCodeEvent: function () {
        var t = this,
            n = this.data.phoneno,
            c = this.data.company,
            u = this.data.username;
        // 国内外手机号正则 判断手机号正误
        let regstr = this.data.reg;
        regstr = regstr.slice(1, regstr.length - 1);
        let reg = new RegExp(regstr);
        if (!reg.test(n)) return wx.showToast({
            title: "手机号有误！",
            icon: "none"
        }), !1;
        // n = `+${this.data.phonecode}-${n}`;
        wx.setStorageSync('phoneno', n); // 存储手机号 上传形式为 +区号-号码
        wx.setStorageSync('company', c);
        wx.setStorageSync('username', u);
        var a = 30,
            o = setInterval(function () {
                a -= 1, t.setData({
                    verifyCodeTime: a + "s后重发",
                    buttonDisable: !0
                }), 0 == a && (clearInterval(o), t.setData({
                    verifyCodeTime: "再次获取",
                    buttonDisable: !1
                }));
            }, 1e3),
            s = wx.getStorageSync("opid");
        // 随机生成验证码赋值
        var code = (Math.random() + '').split(".")[1].slice(0, 4);
        console.log(code);
        this.setData({
            code: code,
            vcode: code
        })
    },
    // 绑定验证码input
    voteVcode: function (e) {
        this.setData({
            vcode: e.detail.value
        });
    },
   
    // 完成按钮
    regist: function () {
        var t = this;
        var n = wx.getStorageSync("openid"), // openid
            a = wx.getStorageSync("userinfo"), // userinfo
            s = t.data.vcode,
            r = wx.getStorageSync('phoneno'),
            c = wx.getStorageSync('company'),
            u = wx.getStorageSync('username');
            console.log(t.data);
           var code = t.data.code;
        null != n && null != a && null != s && "" != s && null != r && "" != r && null != c && "" != c && null != u && "" != u ? wx.showLoading({
            title: '请求中',
            success: () => {
                // 请求验证码 判断
                if (s == code) {
                    t.activatefun();
                } else {
                    t.hideload('验证码错误', 'none')
                }
            },
            fail: err => console.log(err)
        }) : wx.showToast({
            title: "输入信息有误或未输入！",
            icon: "none"
        });
    },
    // 激活情况判断
    activatefun: async function () {
        var that = this;
        // var flag = 
        if (await that.activate()) {
            that.hideload(app.globalData.user_status + '激活成功', 'success');
            jumpTab('index');
        } else {
            that.hideload(app.globalData.user_status + '激活失败', 'none');
        }
    },
    // 隐藏loading
    hideload: function (title, icon) {
        wx.hideLoading({
            success: (res) => {
                wx.showToast({
                    title: title,
                    icon: icon
                })
            },
            fail: err => console.log(err)
        })
    },
    // 验证码正确操作
    activate: function () {
        // 授权
        app.getUserInfo();
        // 获取userinfo
        var userinfo = wx.getStorageSync('userinfo');
        var obj = formatTable('userinfo', userinfo);
        obj.openid = wx.getStorageSync('openid');
        obj.phone_num = wx.getStorageSync('phoneno');
        obj.company = wx.getStorageSync('company');
        obj.username = wx.getStorageSync('username');
        console.log("kw_userinfo", obj);
        console.log("【app.globalData】", app.globalData);
        return new Promise((resolve, reject) => {
            requestPostApi(PATH_REQUEST_UPDATEWXAPPUSER, obj, (res) => {
                if (res.code == 200 && res.data) {
                    var phoneNum = res.data.result.phone_num;
                    if (/^1\d{10}$/.test(phoneNum)) {
                        app.globalData.user_status = 1;
                        app.globalData.enable = res.data.result.enable;
                        resolve(true);
                        // return true;
                    } else {
                        app.globalData.user_status = 0;
                        resolve(false);
                        // return false;
                    }
                } else {
                    wx.showToast({
                        title: res.code + '添加用户失败',
                    })
                }
            }, (err) => {
                console.log(err);
                reject(false);
                // return false;
            });
        });

    },
    // 获取手机号授权
    getPhoneNumber: function (e) {
      wx.login({
        success: (res) => {
          console.log("wx.login",res);
          console.log(e);
          console.log(e.detail.errMsg)
          console.log(e.detail.iv)
          console.log(e.detail.encryptedData)
        },
        fail:(err)=>{
          wx.showToast({
            title: '授权失败',
        })
        }
      })
      },
    getUser: function () {
        return new Promise((resolve, reject) => {
            wx.getUserInfo({
                success: (res) => {
                    console.log(res);
                    var userInfo = res.userInfo;
                    wx.setStorageSync('userinfo', res.userInfo);
                    var obj = {};
                    obj.openid = wx.getStorageSync('openid');
                    obj.userInfo = userInfo;
                    obj.nickName = userInfo.nickName;
                    obj.avatarUrl = userInfo.avatarUrl;
                    obj.gender = userInfo.gender; // 性别 0：未知、1：男、2：女
                    obj.province = userInfo.province;
                    obj.city = userInfo.city;
                    obj.country = userInfo.country;
                    console.log(obj);
                    requestPostApi(PATH_REQUEST_ADDWXAPPUSER, obj, (res) => {
                        resolve(res);
                    }, (err) => {
                        console.log(err);
                        reject(err);
                    })
                },
                fail: (err) => {
                    console.log("【getuserinfo fail】", err)
                    reject(err);
                }
            })
        })
    },
    onLoad: function (e) {},
    onReady: function () {},
    onShow: function () {},
    onHide: function () {},
    onUnload: function () {},
    onPullDownRefresh: function () {},
    onReachBottom: function () {},
    onShareAppMessage: function () {}
});