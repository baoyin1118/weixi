const {
  PATH_REQUEST_GETMODULE,
  PATH_REQUEST_ADDSSQUOTATIONLOG
} = require("../../etc/request");

const {
  calculateWorkday
} = require("../../utils/count");
const {
  formatTable
} = require("../../utils/format");
const {
  requestPostApi
} = require("../../utils/request");


Page({
  /**
   * 页面的初始数据
   */
  data: {
    isBIPModeHidden: false,//控制bip视图隐藏
    bipworkday: 0,//运营官人天
    workmoduleArr:["极速交付","快速交付","敏捷交付"],
    workmodule: "",//交付模式,
    jftype:1,
    businessArr: ["是","否"],
    businesstype:'否',//是否多业态
    biptype:'',//是否BIP模式 /**********************************************
    isChecked: false, // BIP模式按钮（内容隐藏）
    businessRadio:0,//业态系数
    name: '', // 订单名称
    confirmBox:false,//确认名字的框
    tablename: [], // 表格数组
    count: 0,//总费用
    saleparam : 0, //营销云特殊参数：店铺数量1,零售管理10,
    shopNum:1,//店铺数量
    posNum:1,//pos机数量
    tableNum:3,//财务报表数量
    orgNum:1, //组织数量,
    orgRadio:0,//组织系数,
    voucherNum:1,//历史凭证数量
    voucherNumBox:false,//历史凭证数量是否展示
    calculateResult:{},//报价计算结果
    pageOptions: ['BIP模式', '非BIP模式']
  },
  onSwitchChange: function(e) {
    const isChecked = e.detail.value;
     
    // 当开关状态变化时，更新 isChecked 状态
    if (this.data.isChecked !== isChecked) {
      this.setData({
          isChecked: isChecked,
          biptype: isChecked && this.data.biptyp==="是" ? "是" : '否'
      });
     // 跳转到目标页面
    
  }   
  },
    
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 请求表数据
  initTable: function (jftype) {
    let expiration = wx.getStorageSync('jfmoduleExpiration');
    var timestamp = Date.parse(new Date());
    let postapi = false;
    if(expiration < timestamp){
      postapi = true;
    }
    let cachemodule = wx.getStorageSync('jfmodule');
    if(!postapi){
      if(!cachemodule){
        postapi = true;
      }  
    }
    if(postapi){
      // console.log("use api")
      requestPostApi(PATH_REQUEST_GETMODULE, {
        "ssType":jftype,
        "class":1
      }, (res) => {
        if (res.code == "200" && res.data) {
            this.handleResult(res.data.result);
        } else {
          wx.showToast({
            title: res.code + '请求数据错误',
            icon: 'none'
          })
          
        }
      });
    }else{
      // console.log("use cahce");
      let cachelist = [];
      if(jftype == 1){
        cachelist = cachemodule.pro_jisu;
      }else if(jftype == 2){
        cachelist = cachemodule.pro_kuaisu;
      }else if(jftype == 3){
        cachelist = cachemodule.pro_minjie;
      }  
      this.handleResult(cachelist);
    }
  },
  //放置结果到data中
  handleResult:function(resultlist){
    var resultMap = {};
    for(var i in resultlist){
      let e = resultlist[i];
      let lingyu = e.lingyu;
      if(!resultMap[lingyu]){
        resultMap[lingyu] = [];//根据领域划分，键就是领域的值，value是resultlist里面的元素resultMap[key] 是一个数组，包含了所有属于这个区域的数据项
      }
      resultMap[lingyu].push(e);/**将当前的对象 e 添加到 resultMap[lingyu] 对应的数组中。这一步的目的是将相同 lingyu 的对象分类到一起，存储在 resultMap 的相应数组中。 */
    }
    let id = 1;
    var tableArr  = [];
    for(let key in resultMap){
      // console.log(key,resultMap[key]);
      var table = {
        id:id,
        include_licenses: 200,
        is_by_user: "true",
        price:10,
        unit_price: 200,
        user: 10,
        usercount: 0,
        userprice: 0,
        biptype: "否"
      };
      table.head =["模块","远程","现场","选购"];
      table.list = resultMap[key];
      table.name = key;
      tableArr.push(table);
      id++;
    }
    console.log(tableArr);
    this.setData({
      tablename: tableArr
    });
  },
  // Addsub组件传值绑定页面事件
  handleAddsub: function (res) {
    var detail = res.detail;
    var that = this;
    if(detail.hasOwnProperty('shopNum')){
      this.setData({
        shopNum: detail.shopNum
      }, that.goCount());
    }else if(detail.hasOwnProperty('posNum')){
      this.setData({
        posNum: detail.posNum
      }, that.goCount());
    }else if(detail.hasOwnProperty('tableNum')){
      this.setData({
        tableNum: detail.tableNum
      }, that.goCount());
    }else if(detail.hasOwnProperty('orgNum')){
      if(detail.orgNum > 50){
        wx.showToast({
          title: '组织数量大于50,需要线下评估',
          icon: 'none'
        });
        this.setData({
          orgNum: detail.orgNum
        });
      }else{
        this.setData({
          orgNum: detail.orgNum
        }, that.goCount());
      }
    }else if(detail.hasOwnProperty('voucherNum')){
      this.setData({
        voucherNum: detail.voucherNum
      }, that.goCount());
    }
  },
  // Card组件传值绑定页面事件
  handleCard: function (res) {
    var that = this;
    res = res.detail;
    var num = parseInt(res.num.split("_")[1]);
    var json = this.data.tablename;
    json[num].user = res.user;
    json[num].userprice = res.userprice;
    json[num].usercount = res.usercount;
    json[num].price = res.price;
    json[num].list = res.list;
    this.setData({
      tablename: json
    }, () => {
      that.goCount();
    });
  },
  /** */
  // Popup组件传值绑定事件
  handlePopup: function (res) {
    
    res = res.detail;
    this.setData({
      confirmBox: res.show,
      name: res.name
    }, function () {
      if (res.show && res.name) {
        this.sendTrade().then((res) => {
          res = res.data.result;
          this.goPrint(res.quotationid, res.id);
        })
      }
    })
   
  },
  // 跳转Print页面判断逻辑
  goPrintthink: function (e) {


    if(this.data.orgNum > 50){
      wx.showToast({
        title: '组织数量大于50,需要线下评估',
        icon: 'none'
      });
      return false;
    }
   

    if(this.data.businesstype == '' ){
      wx.showToast({
        title: '多业态为必填项，请选择',
        icon: 'none'
      });
      return false;
    }
    if(this.data.biptype == '' ){
      wx.showToast({
        title: 'BIP模式为必填项，请选择',
        icon: 'none'
      });
      return false;
    }
    var menuLength = 0;
    this.data.tablename.map((data) => {
      data.list.map((e) => {
        if(e.checked){
          menuLength++;
        }
      });
    });

    if (menuLength < 1) {
      wx.showToast({
        title: '至少选择一个模块',
        icon: 'none'
      });
      return false;
    }
    if (menuLength < 1) {
      wx.showToast({
        title: '至少选择一个模块',
        icon: 'none'
      });
      return false;
    } 
    var box = this.data.confirmBox;
    var name = this.data.name;
    if(box && name){
      this.sendTrade().then((res) => {
      })
    }else{
      this.setData({
        confirmBox: true,
      })
    }  
  },
  // 保存上传报价
  sendTrade: function () {
    
    var that = this;
    var p = new Promise(function (resolve, reject) {
      var name = that.data.name;
      var userid = wx.getStorageSync('openid');
      var log = that.data.calculateResult;
      log.orgRadio =  that.data.orgRadio;
      log.businessRadio = that.data.businessRadio;
      log.name = name;
      log.user = userid;
      log.checkedlist = JSON.stringify(that.data.calculateResult.checkedlist);
      console.log("sendTradeLog",log);
      requestPostApi(PATH_REQUEST_ADDSSQUOTATIONLOG,log,(res)=>{
        resolve(res);
      },(err)=>{
        reject(err);
      });
    });
    return p;
  },
  // 跳转Print界面
  goPrint: function (historyid, id) {
    this.setData({
      confirmBox: false
    })
    var urldata = '?type=' + this.options.type+'&id=' + id;
 
    wx.redirectTo({
      url: '../record/record' + urldata,
    })
  },
  //选择是否多业态
  bindPickerBusiness: function(e) {
  
    var that = this;
    this.setData({
      businesstype: e.detail.value
    },function() {
      // 在这里访问最新的 businesstype
      //console.log(that.data.businesstype);
      that.goCount(); // 调用 goCount 方法
    });
  },
   //选择是否BIP模式
   bindPickerBIP: function(e) {
  
    var that = this;
    this.setData({
      biptype: e.detail.value
    },function() {
      // 在这里访问最新的 biptype
      //console.log(that.data.biptype);  
      that.goCount(); // 调用 goCount 方法
    });
  },
  //选择三种不同的交付模式
  workmoduleBind:function(e){
    const selectedValue = e.detail.value;
  
    //"极速交付","快速交付","敏捷交付"
    let jftype = 1;
   
    if(e.detail.value == "极速交付"){
      jftype = 1;
    }else if(e.detail.value == "快速交付"){
      jftype = 2;
    }else if(e.detail.value == "敏捷交付"){
      jftype = 3;
    }
    let voucherNumBox = false;
    if(jftype > 1){
      voucherNumBox = true;
    }else{
      voucherNumBox = false;
    }  
    this.setData({
      jftype: jftype,
      voucherNumBox:voucherNumBox,
      workmodule:e.detail.value,
      isBIPModeHidden: (selectedValue === this.data.workmoduleArr[0]) 

    })
    this.initTable(jftype)
  },
  // 计算
  goCount: function () {
    var that = this;
    var table = JSON.parse(JSON.stringify(this.data.tablename));
    formatTable('dayCount', table)
      .then((res) => {
        res = {
          "result": res,
          purchase_period: that.data.year,
          service_fee: that.data.fee,
          shop_num:that.data.shopNum,
          pos_num : that.data.posNum,
          table_num:that.data.tableNum,
          org_num:that.data.orgNum,
          voucher_num:that.data.voucherNum,
          business_type:that.data.businesstype,
          biptype:that.data.biptype
        };
        
        var a = calculateWorkday(res);
        return a;
      })
      .then((r) => {
        this.setData({
          count: r.total,
          fee: r.total,
          workday: r.workday,
          bipworkday: r.bipworkday,
          saleparam: r.saleparam,
          calculateResult:r,
          businessRadio:r.businessRadio,
          orgRadio:r.orgRadio
        })
      });
  }
})