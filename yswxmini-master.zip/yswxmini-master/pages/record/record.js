const {

  PATH_REQUEST_UPDATESHARETIMES,
  PATH_REQUEST_GETSSQUOTATIONLOG
} = require("../../etc/request");
const {
  formatTable
} = require("../../utils/format");
const {
  requestPostApi
} = require("../../utils/request");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tablename: [],
    type: '',
    share: false,
    total:0,
    workday:0,
    orgnum:1,
    orgRaido:1,
    businessRadio:1,
    onsiteDay:0,
    remoteDay:0,
    biptype: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var share = options.share ? true : false;
    console.log("record onload", share, options);
    this.setData({
      type: options.type,
      id: options.id,
      share: share
    });
    this.initTable(options);
  },
  onUnload: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var urldata = '?id=' + this.data.id + '&share=true';
    var obj = {
      title: 'YonSuite实施报价单',
      path: '/pages/record/record' + urldata,
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'],
      success: () => {
        console.log("分享成功");
      },
      fail: (err) => console.log(err)
    }
    wx.showShareMenu(obj);
    return obj;
  },
  goTrade: function (e) {
    var urldata = '?type=addTrade&historyid=' + this.data.historyid + '&id=' + this.data.id;
    wx.navigateTo({
      url: '../trade/trade' + urldata,
    })
  },
  // 初始化表格
  initTable: function (options) {
    var self = this;
    requestPostApi(PATH_REQUEST_GETSSQUOTATIONLOG, {
      
      id: options.id
    }, (res) => {
      if (res.code == "200" && res.data) {
        debugger;
        res = res.data.result[0];
        var tablelist = [];
        var table = {};
        table.name = res.name;
        var checkedlist = JSON.parse(res.checkedlist);
        var jsBean = {}; 
        let on_site_day = 0;
        let remote_day = 0;
        let baon_site_day = 0;
        let saremote_day = 0;
        for(let i = 0;i < checkedlist.length;i++){
          on_site_day += parseFloat(checkedlist[i].on_site_day);
          remote_day += parseFloat(checkedlist[i].remote_day);
          baon_site_day += parseFloat(checkedlist[i].baon_site_day);
          saremote_day += parseFloat(checkedlist[i].saremote_day);
        }
        jsBean.menu = "小计";
        jsBean.on_site_day= on_site_day;
        jsBean.remote_day = remote_day;
        jsBean.baon_site_day= baon_site_day;
        jsBean.saremote_day = saremote_day;
        checkedlist.push(jsBean);
        table.list = checkedlist;
        console.log("table.list",table.list);

        table.choose = false;
        table.head = ["模块","远程人天","现场人天"]
        tablelist.push(table);
        self.setData({
          name: res.name,
          total:res.total,
          workday:res.workday,
          tablename:tablelist,
          orgnum:res.orgnum,
          orgRaido:res.orgRadio,
          businessRadio:res.businessRadio,
          onsiteDay:res.biptype === '是' ? res.baonsiteDay : res.onsiteDay,
          remoteDay:res.biptype === '是' ? res.saremoteDay : res.remoteDay,
          biptype:res.biptype
        });
        console.log(self.data);
      } else {
        wx.showToast({
          title: '请求数据错误',
          icon: 'none'
        })
        console.log("请求错误", res);
      }
    });
  },
  share: function () {
    this.onShareAppMessage();
  },
  // 控制表单显示隐藏
  tableBtn: function (e) {
    var num = e.target.id.split("_")[1];
    var data = this.data.tablename;
    // console.log(data[num].tab);
    var tab = data[num].tab == 'open' ? 'close' : 'open';
    data[num].tab = tab;
    this.setData({
      tablename: data
    })
  },
  // Card组件传值绑定页面事件
  handleCard: function (res) {
   
  },
 
})