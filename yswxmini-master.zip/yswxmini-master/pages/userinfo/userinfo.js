const {
  PATH_REQUEST_QUERYAPPUSER
} = require("../../etc/request");
const {
  formatTable
} = require("../../utils/format");
const {
  jumpPage
} = require("../../utils/jump");
const {
  requestPostApi
} = require("../../utils/request");

// pages/userinfo/userinfo.js
Page({
  data: {
    userinfo: {}, // 用户信息
    realname_status: true, // 实名认证状态
  },
  onShow: function () {
    // var that = this;
    // var obj = {}
    // obj.openid = wx.getStorageSync('openid');
    // requestPostApi(PATH_REQUEST_QUERYAPPUSER, obj, (res) => {
    //   console.log(res);
    //   if (res.code == 200 && res.data) {
    //     res = res.data.result[0];
    //     // 实名用户信息
    //     if (res && !res.ic_number) {
    //       that.setData({
    //         realname_status: false
    //       })
    //     } else {
    //       that.setData({
    //         realname_status: true
    //       })
    //     }
    //     // 微信用户信息
    //     formatTable('infolist', res).then((res) => {
    //       console.log(res)
    //       this.setData({
    //         userinfo: res[0],
    //         realname: res[1]
    //       })
    //     })
    //   } else {
    //     wx.showToast({
    //       title: res.code + '实名信息拉取失败',
    //     })
    //   }
    // }, (res) => {
    //   console.log(res);
    // })
  },
  // goRealName: function () {
  //   jumpPage('realname');
  // }
})