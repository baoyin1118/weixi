const {
    TEMPLATE_HOME
} = require("../../etc/template");
const {
    jumpPage
} = require("../../utils/jump");

var app = getApp();

Page({
    data: {
        tablename: TEMPLATE_HOME
    },
    onShareAppMessage: function () {
        return {
            title: "YonSuite实施报价",
            path: "/pages/index/index"
        };
    },
    onLoad: function () {
        this.setData({
            tablename: TEMPLATE_HOME
        });
        // 加载提示
        wx.showLoading({
          title: 'loadinging',
          mask: true,
          success: app.loginin(), // 获取access_token后获取openid
          fail: err => {
            console.log(err)
          }
          
           
        })
    },
    jumpFun: function (e) {
        if (!app.globalData.user_status) {
            wx.navigateTo({
                url: '../login/login',
            });
        } else if (!app.globalData.enable) {
            wx.showToast({
                title: '您没有访问权限 请联系管理员授权',
                icon: 'none'
            });
        } else {
            var num = e.currentTarget.id.split("_")[1];
            var page = this.data.tablename[num];
            jumpPage(page.page, page.param);
        }
    }
})