Page({
  data: {
    showPopup: false, // 控制弹出框的显示
  },

  // 显示弹出框
  showModal() {
    this.setData({
      showPopup: true,
    });
  },

  // 关闭弹出框
  closePopup() {
    this.setData({
      showPopup: false,
    });
  },

  // 处理选项选择
  handleOptionSelect(event) {
    const selectedValue = event.currentTarget.dataset.value; // 获取选中的值
    this.closePopup(); // 关闭弹出框

    // 根据选择的值调用不同的接口
    switch (selectedValue) {
      case 'option1':
        this.callApiForOption1();
        break;
      case 'option2':
        this.callApiForOption2();
        break;
      case 'option3':
        this.callApiForOption3();
        break;
      default:
        console.log('无效选项');
    }
  },

  // 接口调用示例
  callApiForOption1() {
    wx.request({
      url: 'https://example.com/api/option1',
      method: 'GET',
      success(res) {
        console.log('Option 1 response:', res.data);
      },
      fail(err) {
        console.error('Option 1 request failed:', err);
      }
    });
  },

  callApiForOption2() {
    wx.request({
      url: 'https://example.com/api/option2',
      method: 'GET',
      success(res) {
        console.log('Option 2 response:', res.data);
      },
      fail(err) {
        console.error('Option 2 request failed:', err);
      }
    });
  },

  callApiForOption3() {
    wx.request({
      url: 'https://example.com/api/option3',
      method: 'GET',
      success(res) {
        console.log('Option 3 response:', res.data);
      },
      fail(err) {
        console.error('Option 3 request failed:', err);
      }
    });
  },
});