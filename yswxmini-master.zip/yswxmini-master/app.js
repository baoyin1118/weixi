// app.js

const {
  getToken
} = require('./utils/token.js');
const {
  token_param,
  PATH_REQUEST_GETWXOPENID,
  PATH_REQUEST_QUERYAPPUSER,
  PATH_REQUEST_ADDWXAPPUSER,
  PATH_REQUEST_UPDATEWXAPPUSER,
  PATH_REQUEST_GETMODULE
} = require("./etc/request");
const {
  requestPostApi
} = require("./utils/request");
const {
  formatTable
} = require('./utils/format.js');
App({
  onLaunch: function () {
    // 存储打开时间
    var logs = wx.getStorageSync('logs') || [];
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs);
    // 获取用户信息
     this.getUserInfo();
      //储存报价配置
     this.storeModule();
  },

  onShow:function(){
   
  },

  //初始化配置
  storeModule:function(){
    requestPostApi(PATH_REQUEST_GETMODULE,{},(res)=>{
      if (res.code == "200" && res.data) {
        var mlist = res.data.result;
        // console.log("mlist",mlist);
        var jfmodule = {};
        //专业版极速交付
        var pro_jisu = [];
        //专业版快速交付
        var pro_kuaisu =[];
        //专业版敏捷交付
        var pro_minjie = [];
        //交付包极速交付
        var pack_jisu =[];
        //交付包快速交付
        var pack_kuaisu=[];

        mlist.forEach((e)=>{
          if(e.ss_class == 1){   
            if(e.ss_type == 1){
              pro_jisu.push(e);
            }else if(e.ss_type == 2){
              pro_kuaisu.push(e);
            }else if(e.ss_type == 3){
              pro_minjie.push(e);
            }
          }else if(e.ss_class == 2){
            if(e.ss_type == 1){
              pack_jisu.push(e);
            }else if(e.ss_type == 2){
              pack_kuaisu.push(e);
            }
          }
        });

        pro_jisu.sort(this.sort);
        pro_kuaisu.sort(this.sort);
        pro_minjie.sort(this.sort);
  
        jfmodule.pro_jisu = pro_jisu;
        jfmodule.pro_kuaisu = pro_kuaisu;
        jfmodule.pro_minjie = pro_minjie;
        jfmodule.pack_jisu = pack_jisu;
        jfmodule.pack_kuaisu = pack_kuaisu;
        wx.setStorageSync('jfmodule', jfmodule);
        var timestamp = Date.parse(new Date());
        var expiration = timestamp + 60000 * 60 * 24; //缓存1天
        wx.setStorageSync('jfmoduleExpiration',expiration);
        // console.log("缓存交付配置",jfmodule);
      }
    },(err)=>{
      console.log("初始化配置失败");
    })
  },
  //排序
  sort : function(a,b){
    //排序依据
    let sort_map = new Map();
    sort_map.set("财务云",10);
    sort_map.set("供应链云",20);
    sort_map.set("采购云",30);
    sort_map.set("制造云",40);
    sort_map.set("项目云",50);
    sort_map.set("人力云",60);
    sort_map.set("营销云",70);
    sort_map.set("资产云",80);
    sort_map.set("协同云",90);
    sort_map.set("银企联云",100);
    let a_sorce = 1000;
    if(sort_map.has(a.lingyu)){
      a_sorce = sort_map.get(a.lingyu);
    }
    let b_sorce = 2000;
    if(sort_map.has(b.lingyu)){
      b_sorce = sort_map.get(b.lingyu);
    }
    return a_sorce - b_sorce;
  },

  // 登录
  loginin: function () {
    var that = this;
    that.getOpenid().then(() => {
      return that.getUser();
    }).then((res) => {
   
      var enable = res.enable == null ? 0 : res.enable;
      var user_status = res.phone_num == null ? 0 : 1;
      // let user_status = phone.indexOf('undefined') < 0 ? 1 : 0;
      // phone = phone.indexOf('undefined') < 0 ? true : false;
      // 添加用户 判断是否需要激活
      that.addUser().then((res) => {
       
        that.globalData.user_status = user_status;
       
      });
      // 赋值
      that.globalData.enable = enable;
      // 隐藏loading
      wx.hideLoading();
    }, (y) => {

      that.globalData.user_status = 0;
      wx.hideLoading({
        success: () => {
          wx.showToast({
            title: y + '服务错误 请重新打开小程序！',
            icon: 'none'
          })
        }
      })
    })
  },
  // 获取token
  getToken: function () {
    return new Promise((resolve, reject) => {
      var token = wx.getStorageSync("token_data") || undefined;
      if (token) {
        var time = new Date().getTime();
        // 超时重新获取token
        if (token.expire <= time) {
          getToken(token_param).then((res, rej) => {
            res = res.data;
            wx.getStorage({
              key: 'token_data',
              success: function (r) {
                resolve(r)
              }
            });
          });
        }
        resolve(token);
      } else {
        // 首次获取token
        getToken(token_param).then((res, rej) => {
          res = res.data;
          console.log("token",res)
          wx.getStorage({
            key: 'token_data',
            success: function (r) {
             
              resolve(r);
            }
          });
        });
      }
    })
  },
  // 获取openid
  getOpenid: function () {
    var that = this;
    return new Promise((resolve, reject) => {
      wx.login({
        success: res => {
          wx.hideLoading()
          wx.setStorageSync('code', res.code);
          var obj = {
            code: res.code
          }
          that.postopenid(obj, 5, resolve, reject);
        },
        fail : err =>{
          wx.hideLoading();
        }
      })
    })
  },
  // 请求openid
  postopenid: function (obj, num, resolve, reject) {
    var that = this;
    requestPostApi(PATH_REQUEST_GETWXOPENID, obj, (res) => {
      if (res.code == "200") {
        wx.setStorageSync('openid', res.data.openid);
        resolve(res);
      } else {
        if (num <= 1) {
          wx.hideLoading({
            success: () => {
              wx.showToast({
                title: '获取openid失败',
                icon: 'none'
              });
              reject("获取openid失败");
            }
          });
        } else {
          that.postopenid(obj, --num, resolve, reject);
        }
      }
    }, (err) => {
      wx.showToast({
        title: err,
        icon: 'none'
      })
      reject(err);
    })
  },
  // 添加用户
  addUser: function () {
    return new Promise((resolve, reject) => {
      // var that = this;
      var openid = wx.getStorageSync('openid');
      requestPostApi(PATH_REQUEST_ADDWXAPPUSER, {
        openid: openid
      }, (res) => {
      
        if (res.code == '200' && res.data.result.openid != null) {
          // if (res.code != '999') {
          resolve(true);
        } else {
          resolve(false);
        }
      }, (err) => {
       
        reject(false);
      })
    })
  },
  // 获取后台是否有该用户信息
  getUser: function () {
    return new Promise((resolve, reject) => {
      var openid = wx.getStorageSync('openid');
      requestPostApi(PATH_REQUEST_QUERYAPPUSER, {
        openid: openid
      }, (res) => {
        if (res.data.result && res.data.result.length == 0) {
          resolve(false);
        } else {
          resolve(res.data.result[0]);
        }
      }, (err) => {
        reject(false);
      })
    })
  },
  // post用户信息
  postUserInfo: async function () {
  
    var userinfo = wx.getStorageSync('userinfo');
    var obj = await formatTable('userinfo', userinfo);
    obj.openid = wx.getStorageSync('openid');
    requestPostApi(PATH_REQUEST_UPDATEWXAPPUSER, obj, (res) => {
      this.globalData.user_status = 1;
      return true;
    }, (err) => {
      return false;
    })
  },
  // 获取用户信息
  getUserInfo: function () {
    var that = this;
    wx.getUserInfo({
      success: (res) => {
        wx.setStorageSync('userinfo', res.userInfo);
        that.globalData.userinfo = res.userInfo || null;
        that.postUserInfo();
        return res.userInfo;
      },
      fail: (err) => {
        console.log("getUserInfo|===>",err);
        that.globalData.userinfo = null;
        return {}
      }
    })
  },
  // 用户信息授权
  authUserInfo: function () {
    var that = this;
    wx.getSetting({
      success: (res) => {
        if (!res.authSetting["scope.userInfo"]) {
          wx.authorize({
            scope: 'userInfo',
            success: () => {
              that.getUserInfo();
            },
            fail: (res) => {
              
            },
          })
        }
      },
      fail: (err) => {
      
      }
    })
  },
  // 获取地理位置
  // getLocation: function (params) {
  //   // wx.getLocation({
  //   //   type: 'wgs84',
  //   //   success(res) {
  //   //     const latitude = res.latitude
  //   //     const longitude = res.longitude
  //   //     const speed = res.speed
  //   //     const accuracy = res.accuracy
  //   //     return res;
  //   //   },
  //   //   fail: function (err) {
  //   //     wx.showToast({
  //   //       title: err,
  //   //     })
  //   //   }
  //   // })
  // },
  //全局变量
  globalData: {
    userinfo: null,
    user_status: 0, // 登录状态 0为未登录 1为登录
    enable: 0, // 访问权限 1为允许访问 0为不允许访问
  }
})